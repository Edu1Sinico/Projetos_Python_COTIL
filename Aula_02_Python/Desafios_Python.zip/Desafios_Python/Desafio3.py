num = int(input("Digite um número: "))

print(f"\nO número antecessor e o sucessor do número ({num}) são respectivamente: {num - 1} e {num + 1}")