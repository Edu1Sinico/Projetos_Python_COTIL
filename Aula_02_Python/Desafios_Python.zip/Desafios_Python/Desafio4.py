import math as mt

valor = float(input("Digite um valor: "))

print(f"O dobro do valor digitado é: {valor*2}")
print(f"O triplo do valor digitado é: {valor*3}")
print(f"A raiz quadrada do valor digitado é: {mt.sqrt(valor)}")
