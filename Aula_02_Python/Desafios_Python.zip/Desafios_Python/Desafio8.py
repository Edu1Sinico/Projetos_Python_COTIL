valor = float(input("Digite sua renda: "))

print("Valor em dolar que você pode comprar é: US$ ",(valor/5))