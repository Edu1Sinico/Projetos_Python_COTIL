valor1 = float(input("Digite um número: "))
valor2 = float(input("Digite um segundo valor: "))

print(f"A soma dos números digitado é { valor1 + valor2}")


